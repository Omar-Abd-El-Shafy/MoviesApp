import React from "react";
import Movies from "../components/movies";

function Home(props) {
  return (
    <>
      <Movies />
    </>
  );
}

export default Home;
