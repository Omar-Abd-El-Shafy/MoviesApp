import React from 'react';
import SearchResult from '../components/search/SearchResult';

function Search(props) {
    return (
        <>
        <SearchResult/>
        </>
    );
}

export default Search;